from flask import render_template, request, redirect, url_for
import sqlite3
from app import app

@app.route('/')
def index():
    with sqlite3.connect('shop.db') as conn:
        c = conn.cursor()
        c.execute('SELECT * FROM products')
        products = c.fetchall()
    return render_template('index.html', products=products)

@app.route('/product_detail/<int:product_id>')
def product_detail(product_id):
    with sqlite3.connect('shop.db') as conn:
        conn.row_factory = sqlite3.Row  
        c = conn.cursor()
        c.execute('SELECT * FROM products WHERE id = ?', (product_id,))
        product = dict(c.fetchone()) 
        image_url = ("/" if not product['image_url'].startswith("/") else "") + product['image_url']
    return render_template('product_detail.html', product=product, image_url=image_url)



@app.route('/cart')
def cart():
    with sqlite3.connect('shop.db') as conn:
        c = conn.cursor()
        c.execute('''
            SELECT c.id, p.name, p.price, c.quantity, p.image_url
            FROM cart c
            JOIN products p ON c.product_id = p.id
        ''')
        cart_items = c.fetchall()
    return render_template('cart.html', cart_items=cart_items)

@app.route('/add_to_cart/<int:product_id>')
def add_to_cart(product_id):
    with sqlite3.connect('shop.db') as conn:
        c = conn.cursor()
        c.execute('INSERT INTO cart (product_id, quantity) VALUES (?, ?)', (product_id, 1))
        conn.commit()
    return redirect(url_for('cart'))

@app.route('/remove_from_cart/<int:cart_id>')
def remove_from_cart(cart_id):
    with sqlite3.connect('shop.db') as conn:
        c = conn.cursor()
        c.execute('DELETE FROM cart WHERE id = ?', (cart_id,))
        conn.commit()
    return redirect(url_for('cart'))
# app/routes.py
from flask import render_template, request, redirect, url_for
import sqlite3
from app import app

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']

        with sqlite3.connect('shop.db') as conn:
            c = conn.cursor()
            
            c.execute('''
                SELECT SUM(p.price * c.quantity)
                FROM cart c
                JOIN products p ON c.product_id = p.id
            ''')
            total_price = c.fetchone()[0] or 0
            
            c.execute('''
                INSERT INTO orders (customer_name, customer_email, total_price, order_date)
                VALUES (?, ?, ?, datetime('now'))
            ''', (name, email, total_price))
            order_id = c.lastrowid

            c.execute('''
                SELECT product_id, quantity
                FROM cart
            ''')
            cart_items = c.fetchall()
            for item in cart_items:
                product_id, quantity = item
                c.execute('''
                    INSERT INTO order_details (order_id, product_id, quantity)
                    VALUES (?, ?, ?)
                ''', (order_id, product_id, quantity))

            c.execute('DELETE FROM cart')

            conn.commit()

        return redirect(url_for('order_confirmation', order_id=order_id))
    else:
        return render_template('checkout.html')


@app.route('/order_confirmation/<int:order_id>')
def order_confirmation(order_id):
    with sqlite3.connect('shop.db') as conn:
        c = conn.cursor()
        c.execute('SELECT * FROM orders WHERE id = ?', (order_id,))
        order = c.fetchone()

        c.execute('''
            SELECT p.name, p.price, od.quantity
            FROM order_details od
            JOIN products p ON od.product_id = p.id
            WHERE od.order_id = ?
        ''', (order_id,))
        order_details = c.fetchall()
    
    return render_template('order_confirmation.html', order=order, order_details=order_details)
